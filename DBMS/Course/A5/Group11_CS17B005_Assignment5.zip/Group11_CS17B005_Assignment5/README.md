### Instructions to execute source-code

1. System should have 'java.sql' jar package installed 
2. Location of above jar file must be added to the CLASSPATH
3. System should have academic_insti schema in it's local server
4. URL used in the code is "jdbc:mysql://localhost:3306/academic_insti", this can be changed upon requirment
5. Compile using 'javac a5_dbms.java' in source directory
6. Run using 'java a5_dbms'
7. The input specifications are clearly requested with print statments