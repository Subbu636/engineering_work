


<train.en> which contains 22,165 setences in english and the corresponding telugu translated sentences in <train.te>.

use the above files for training and <dev.en>, <dev.te> for validation.
