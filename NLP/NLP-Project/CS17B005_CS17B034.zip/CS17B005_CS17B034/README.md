# Search_Engine
The folders contain their respective source codes
