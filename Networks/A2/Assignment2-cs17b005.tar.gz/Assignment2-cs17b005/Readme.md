The four python files to excute are named as given in the assignment!
As the language is python the code is an excutable
Debug data is printed as a python list for now and can be changed whenever required
Jupyter Notebook files are available for reference
standard parameters are :

for GBN:

UDP_IP = "127.0.0.1"
UDP_PORT = 1235
OTHER_PORT = 6363
RANDOM_DROP_PROB = 0.1
MAX_PACKETS = 100
DEBUG_MODE = False
DEBUG_MODE = False
R_ADDRESS = "127.0.0.1"
R_PORT_NUMBER = 1235
OTHER_PORT = 6363
PACKET_LENGTH = 32
PACKET_GEN_RATE = 1000
MAX_PACKETS = 100
WINDOW_SIZE = 3
MAX_BUFFER_SIZE = 10

for SR:

DEBUG_MODE = False
R_ADDRESS = "127.0.0.1"
R_PORT_NUMBER = 1235
OTHER_PORT = 6363
PACKET_LENGTH = 32
PACKET_GEN_RATE = 1000
MAX_PACKETS = 100
WINDOW_SIZE = 3
MAX_BUFFER_SIZE = 10
UDP_IP = "127.0.0.1"
UDP_PORT = 1235
OTHER_PORT = 6363
RANDOM_DROP_PROB = 0.1
MAX_PACKETS = 100
DEBUG_MODE = False