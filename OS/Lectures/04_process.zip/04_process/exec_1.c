#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  char *exec_argv[3];
  exec_argv[0] = "echo";
  exec_argv[1] = "hello world";
  exec_argv[2] = 0;
  execvp("/bin/echo", exec_argv);
  return -1; 
}
