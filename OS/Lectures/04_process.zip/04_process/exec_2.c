#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  if (argc < 2) {
    printf("Exiting\n");
    return 0;
  }
  if (atoi(argv[1]) == 1) {
    char *exec_argv[2];
    exec_argv[0] = "exec_2";
    exec_argv[1] = 0;
    execvp("./exec_2", exec_argv);
  }
  return 0; 
}
