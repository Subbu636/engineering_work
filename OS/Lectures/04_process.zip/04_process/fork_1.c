#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  int rc = fork();
  if (rc < 0) { 
    fprintf(stderr, "Error\n");
    exit(1);
  } 
  else if (rc == 0) { 
    printf("(%d) Hello from child! I got %d. My parent is %d\n", (int) getpid(), rc, (int) getppid()); 
    } else { 
      printf("(%d) Hello from parent! I got %d. My parent is %d\n", (int) getpid(), rc, (int) getppid());
    }
  return 0; 
}
