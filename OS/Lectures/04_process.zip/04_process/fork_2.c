#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (int argc, char *argv[]) {
  int i=0;
  printf("(%d) Start\n", (int) getpid()); 
  int rc = fork();
  if (rc < 0) { 
    fprintf(stderr, "Error\n");
    exit(1);
  } 
  else if (rc == 0) { 
    i = 1;
    printf("(%d) Hello from child! i = %d\n", (int) getpid(), i); 
    } else { 
      i = 2;
      printf("(%d) Hello from parent! i = %d\n", (int) getpid(), i);
    }
  return 0; 
}
