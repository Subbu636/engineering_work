#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  char *exec_argv[2];
  exec_argv[0] = "ls";
  exec_argv[1] = 0;
  if (fork() == 0) {
    printf("(%d) In child\n", (int) getpid());
    execvp("/bin/ls", exec_argv);
    return -1;
  }
  printf("(%d) Back in parent and waiting\n", (int) getpid());
  int status;
  waitpid(-1, &status, 0);
  printf("(%d) Done\n", (int) getpid());
  return 0; 
}
