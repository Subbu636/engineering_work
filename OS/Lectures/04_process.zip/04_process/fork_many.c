#include <unistd.h>     
#include <stdio.h>      
#include <stdlib.h>
#include <sys/wait.h> 

int main(int argc, char *argv[]) {
  for (size_t i = 0; i < 8; i++) {
    int rc = fork();
    if (rc == 0) exit(200 + i);
  }
  while (1) {
    int status;
    int rc = waitpid(-1, &status, 0);
    if (rc == -1) break;
    if (WIFEXITED(status)) {
      printf("Child %d returned with %d\n", rc, WEXITSTATUS(status));
    } else {
      printf("Child %d terminated abnormally.\n", rc);
    }
  }
  return 0;
}
