#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  int rc = fork();
  if (rc < 0) { 
    fprintf(stderr, "Error\n");
    exit(1);
  } 
  else if (rc == 0) { 
    printf("(%d) Hello from child! Parent is %d\n", (int) getpid(), (int) getppid()); 
    } else { 
      int wc = wait(NULL);
      printf("(%d) Hello from parent! Wait ret = %d. Parent is %d\n", (int) getpid(), wc, (int) getppid());
    }
  return 0; 
}
