#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  int rc = fork();
  if (rc < 0) { 
    fprintf(stderr, "Error\n");
    exit(1);
  } 
  else if (rc == 0) { 
    printf("(%d) Hello from child!\n", (int) getpid()); 
    // int i = 1/0;
    } else { 
      int status;
      int wc = waitpid(rc, &status, 0);
      if (WIFEXITED(status)) {
        printf("(%d) Hello from parent! Child with pid %d exited with status %d.\n", (int) getpid(), wc, WEXITSTATUS(status));
      } else {
        printf("(%d) Hello from parent! Child with pid %d exited abnormally.\n", wc, (int) getpid());
      }
    }
  return 0; 
}
