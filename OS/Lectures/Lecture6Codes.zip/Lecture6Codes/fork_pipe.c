#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main (int argc, char *argv[]) {
  int p[2];
  pipe(p);
	char *c = (char *) calloc(100, sizeof(char));

  if (fork() > 0) {
    // sleep(1);
	  write(p[1], "hello child", 11);
  } else {
    read(p[0], c, 11);
		printf("Got %s from parent\n", c);
  }
  return 0; 
}
