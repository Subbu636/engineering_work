#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (int argc, char *argv[]) {
  int p[2];
  pipe(p);
	int N = 3;
	int p_sleep = atoi(argv[1]);

  if (fork() == 0) {
	  if (p_sleep)
		  sleep(1);
		for (int i=0; i<N; i++) {
	  	write(p[1], "p", 1);
		}
  } else {
	  if (!p_sleep)
	    sleep(1);
		for (int i=0; i<N; i++) {
	  	write(p[1], "c", 1);
		}
		char c_in;
		for (int i=0; i<2*N; i++) {
      read(p[0], &c_in, 1);
		  printf("Got %c from pipe\n", c_in);
		}
  }
  return 0; 
}
