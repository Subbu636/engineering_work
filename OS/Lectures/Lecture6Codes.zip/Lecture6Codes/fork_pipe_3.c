#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main (int argc, char *argv[]) {
  int p[2];
  pipe(p);

  char *exec_argv[2];
  exec_argv[0] = "wc";
  exec_argv[1] = 0;

  if (fork() == 0) {
    close(0);
    dup(p[0]);
    close(p[0]);
    close(p[1]);
    execvp("/bin/wc", exec_argv);
  } else {
    write(p[1], "hello world\n", 12);
    close(p[0]);
    close(p[1]);
  }
  return 0; 
}
