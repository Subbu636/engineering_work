#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <string.h>
#include <unistd.h>

int main() {

  char* shmem = mmap(NULL, 128, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_SHARED, -1, 0); 

  memcpy(shmem, "Srinivasa", 9);
  printf("(%d) Wrote: %s\n", getpid(), shmem);

  int pid = fork();

  if (pid == 0) {
    printf("(%d) Read: %s\n", getpid(), shmem);
    memcpy(shmem, "Ramanujan", 9);
    printf("(%d) Wrote: %s\n", getpid(), shmem);
  } else {
    printf("(%d) Read: %s\n", getpid(), shmem);
    sleep(1);
    printf("(%d) Read: %s\n", getpid(), shmem);
  }
}
