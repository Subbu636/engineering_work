#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

int main() {
  char* name = "cs3500";
  int size = 128;
  int pid = getpid();

  int fd = shm_open(name, O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
  ftruncate(fd, size);
  char* shmem = mmap(NULL, 128, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0); 

  printf("(%d) Got fd %d\n", pid, fd);

  memcpy(shmem, "Srinivasa", 9);
  printf("(%d) Wrote: %s\n", pid, shmem);
  sleep(2);
  printf("(%d) Read: %s\n", pid, shmem);
}
