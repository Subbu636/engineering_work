#include<stdio.h>
#include<signal.h>
#include<unistd.h>

void sig_handler(int signo)
{
  if (signo == SIGINT)
    printf("Received SIGINT and overriding default\n");
}

int main(void)
{
  printf("My pid is %d\n", getpid());
  if (signal(SIGKILL, sig_handler) == SIG_ERR)
     printf("Can't catch SIGKILL\n");
  if (signal(SIGSTOP, sig_handler) == SIG_ERR)
     printf("Can't catch SIGSTOP\n");
  if (signal(SIGINT, sig_handler) == SIG_ERR)
     printf("Can't catch SIGINT\n");
  while(1) 
    sleep(1);
  return 0;
}
