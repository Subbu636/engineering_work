#include<stdio.h>
#include<signal.h>
#include<unistd.h>

void sig_handler(int signo)
{
    if (signo == SIGUSR1)
        printf("Received SIGUSR1, custom handler\n");
}

int main(void)
{
  printf("(%d) Starting\n", getpid());
  if (signal(SIGUSR1, sig_handler) == SIG_ERR)
    printf("Can't catch SIGUSR1\n");
  while(1) 
    sleep(1);
  return 0;
}
