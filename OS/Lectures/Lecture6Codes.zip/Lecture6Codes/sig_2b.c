#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <signal.h>

int main (int argc, char *argv[]) {
  printf("(%d) Start\n", (int) getpid()); 
  char *exec_argv[2];
  exec_argv[0] = "sig_2";
  exec_argv[1] = 0;
  int pid = fork();
  if (pid == 0) {
    printf("(%d) In child\n", (int) getpid());
    execvp("./sig_2", exec_argv);
    return -1;
  }
  printf("(%d) Done \n", (int) getpid());
  sleep(1);
  kill(pid, SIGUSR1);
  printf("(%d) Done \n", (int) getpid());
  return 0; 
}
