
# PART-1 Q-Learning and SARSA :

Jupyter notebook file(.ipynb) named Q-Learning and SARSA have all the corresponding to part 1 of the assignment.

The environment is class named custom grid world. It has all the functions with intutive names.
Based on input given A or B or C we choose the variants
The rendering pretty premitive and will print the path of agent in the grid.
The consecutive cells will be having Qlearning, its plots, single SARSA(LAMDA), its plots, multiple lamda SARSA and its plots
Each cell is commented with its work Major steps of code are commented



# PART-2 Policy Gradient :

Jupyter notebook files(.ipynb) named PG-chakra and PG-vishamC have all the corresponding to part 2 of the assignment.
The setup and regester of chakra in the directory named chakra but these are directly used as classes in the notebooks.

Chakra class has mode variable which when given name of environment as string ('chakra' or 'vishamC') will run corresponding envs.
The environment is setup and regestered as in gym as said in part 1 of question
Although class is directly used in notebooks.
The next cell will be having Rollout function part 2 of the question.
Inspired from rollout the next cells have functions for pulling an act etc
Next cell will be having Policy Gradient algo
The next are required plots.

