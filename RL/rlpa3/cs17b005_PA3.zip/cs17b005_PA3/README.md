Name: Arabhi Subhash
Roll: cs17b005

Info:
1. Both the assignmets are submitted in jupyter notebook format ( .ipynb files )
2. The naming is rlpa3_1, rlpa3_2_*
3. Whole assignment is done including bonus parts
4. All the quesions are answered in the report
5. For second question the trained parameters are stored using Tensorflow save in folders with names same as file names
6. The episodic rewards are stored in .npy format for reference, we can directly plot without training again
7. For Q2 rlpa3_2 has the main code, same is copied and altered in other files
8. For Q1 different varaibles used are explained in a markdown cell at the start
